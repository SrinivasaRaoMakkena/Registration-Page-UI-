package com.example.srinivas.interfragmentcommunication;

/**
 * Created by Srinivas on 6/13/2017.
 */

public interface MyListener {

    void add(int a,int b);
}
