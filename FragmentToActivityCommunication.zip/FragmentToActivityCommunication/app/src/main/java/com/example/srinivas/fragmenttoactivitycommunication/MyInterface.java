package com.example.srinivas.fragmenttoactivitycommunication;

/**
 * Created by Srinivas on 6/12/2017.
 */

public interface MyInterface {

     void add(int a,int b);
}
